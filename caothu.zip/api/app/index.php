<?php
// Silence is Good
