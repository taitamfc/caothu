<?php
// Directories Constants
define('CACHE', 'cache/');
define('SYSTEM', 'system/');
define('VIEWS', 'app/views/');
define('CONTROLLER', 'app/controllers/');
define('ASSETS', 'assets/');
define('LIBRARIES', 'app/libraries/');
define('MODELS', 'app/models/');
define('DB_HOST', 'localhost');
define('DB_USER', 'vaobo_api');
define('DB_PASSWORD', 'NiJqHNzL');
define('API_KEY', 'y25uTh1LaqOWj4tN');
define('API_URL', 'http://api-asia.isportsapi.com');

